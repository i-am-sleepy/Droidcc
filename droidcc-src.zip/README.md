# DroidCC
On-device clang/lld/ninja for aarch64 Android, in a self-contained app.

Layout: app/ (Kotlin app), ci/ (scripts building clang+lld+llvm-ar, ninja, sysroot), build.yml (GitHub workflow).

In the app: Install -> Self-test. Then use the command box, e.g. `ninja -j2` in your project dir.
In your build.ninja: `include /data/user/0/com.droidcc.app/files/toolchain/toolchain.ninja`
then use rules cc, cxx, link_so, link_exe, ar (set `cflags`, `ldflags`, `libs` per build edge).

Notes
- Output .so files can be System.load()ed by an app. Standalone executables cannot be exec'd from app data on Android 10+.
- Use `-j2`/`-j3`; big recomp C files are RAM-hungry. Split output into many TUs.
