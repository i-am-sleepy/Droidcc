plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.droidcc.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.droidcc.app"
        minSdk = 28            // toolchain is built against API 28 (posix_spawn etc.)
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
        ndk { abiFilters += "arm64-v8a" }
    }

    packaging {
        // Extract .so files to nativeLibraryDir so our "libclang.so" etc. are real executable files.
        jniLibs { useLegacyPackaging = true }
    }
    androidResources { noCompress += "zip" }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
