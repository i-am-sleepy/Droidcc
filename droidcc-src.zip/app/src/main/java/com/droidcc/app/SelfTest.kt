package com.droidcc.app

/** Bound at runtime to a library that DroidCC itself compiled (see MainActivity.selfTest). */
object SelfTest {
    @JvmStatic external fun add(a: Int, b: Int): Int
}
