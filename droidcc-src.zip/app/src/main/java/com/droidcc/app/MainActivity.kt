package com.droidcc.app

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.text.InputType
import android.view.View
import android.widget.*
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var tc: Toolchain
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var dirEdit: EditText
    private lateinit var cmdEdit: EditText
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tc = Toolchain(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 48, 24, 24) }
        dirEdit = EditText(this).apply {
            hint = "working directory"
            setText(File(getExternalFilesDir(null) ?: filesDir, "projects").absolutePath)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        cmdEdit = EditText(this).apply {
            hint = "command (e.g. ninja -j2)  |  loadlib /path/to/lib.so"
            setText("ninja -j2")
            inputType = InputType.TYPE_CLASS_TEXT
        }
        logView = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 11f; setTextIsSelectable(true) }
        scroll = ScrollView(this).apply { addView(logView) }

        fun row(vararg b: Button) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            b.forEach { addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        root.addView(dirEdit)
        root.addView(cmdEdit)
        root.addView(row(btn("Install") { bg { install() } }, btn("Self-test") { bg { selfTest() } }))
        root.addView(row(btn("Run") { runCmd() }, btn("Stop") { tc.stop() }, btn("Clear") { logView.text = "" }))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        log("DroidCC ready. Toolchain installed: ${tc.isInstalled()}")
        if (!tc.isInstalled()) log("Tap Install first.")
    }

    private fun log(s: String) = ui.post {
        logView.append(s + "\n")
        if (logView.length() > 300_000) logView.text = logView.text.takeLast(150_000)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun bg(f: () -> Unit) = thread {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "droidcc:build").apply { acquire(6 * 3600_000L) }
        try { f() } catch (t: Throwable) { log("ERROR: $t") } finally { if (wl.isHeld) wl.release() }
    }

    private fun install() { tc.install(::log) }

    private fun runCmd() {
        val cmd = cmdEdit.text.toString().trim()
        val dir = File(dirEdit.text.toString())
        if (cmd.startsWith("loadlib ")) {
            try { System.load(cmd.removePrefix("loadlib ").trim()); log("loaded") } catch (t: Throwable) { log("ERROR: $t") }
            return
        }
        bg {
            if (!tc.isInstalled()) { log("Not installed - tap Install"); return@bg }
            log("\$ $cmd   (in $dir)")
            val rc = tc.run(cmd, dir, ::log)
            log("[exit $rc]")
        }
    }

    /** Compiles a C++ JNI library with the on-device toolchain, dlopen()s it and calls into it. */
    private fun selfTest() {
        if (!tc.isInstalled()) { log("Not installed - tap Install"); return }
        val dir = File(cacheDir, "selftest").apply { deleteRecursively(); mkdirs() }
        val lib = "libselftest${System.currentTimeMillis()}.so"
        File(dir, "t.cpp").writeText(
            """
            #include <jni.h>
            #include <string>
            extern "C" JNIEXPORT jint JNICALL
            Java_com_droidcc_app_SelfTest_add(JNIEnv*, jclass, jint a, jint b) {
                std::string s("ab");
                return a + b + (jint)s.size() - 2;
            }
            """.trimIndent()
        )
        File(dir, "build.ninja").writeText(
            "include ${tc.ninjaInclude.absolutePath}\n" +
            "build t.o: cxx t.cpp\n  cflags = -O2 -std=c++17\n" +
            "build $lib: link_so t.o\n"
        )
        log("== self-test: compile + link ==")
        val rc = tc.run("ninja -v", dir, ::log)
        if (rc != 0) { log("self-test FAILED at build (exit $rc)"); return }
        System.load(File(dir, lib).absolutePath)
        val r = SelfTest.add(2, 3)
        log(if (r == 5) "self-test PASSED: compiled on-device, loaded, add(2,3)=5" else "self-test FAILED: got $r")
    }
}
