#!/usr/bin/env bash
# Packs the aarch64 NDK sysroot + clang resource dir into sysroot.zip (an app asset).
set -euxo pipefail
: "${NDK:?}"
API=28
P="$NDK/toolchains/llvm/prebuilt/linux-x86_64"
SR="$P/sysroot"
rm -rf pkg && mkdir -p pkg/sysroot/usr/lib pkg/resource/lib/linux

cp -r "$SR/usr/include" pkg/sysroot/usr/
rm -rf pkg/sysroot/usr/include/{arm-linux-androideabi,i686-linux-android,x86_64-linux-android,riscv64-linux-android}

cp -r "$SR/usr/lib/aarch64-linux-android" pkg/sysroot/usr/lib/
# keep only API 28 stubs
find pkg/sysroot/usr/lib/aarch64-linux-android -mindepth 1 -maxdepth 1 -type d \
  ! -name "$API" -exec rm -rf {} +

CLANGDIR=$(ls -d "$P"/lib/clang/*/ | head -n1)
cp -r "$CLANGDIR/include" pkg/resource/
cp -r "$CLANGDIR"/lib/linux/*aarch64* pkg/resource/lib/linux/

du -sh pkg/*
mkdir -p out/extras
(cd pkg && zip -qr ../out/extras/sysroot.zip .)
ls -l out/extras
