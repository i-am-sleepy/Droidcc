#!/usr/bin/env bash
# Cross-compiles clang + lld + llvm-ar for aarch64-linux-android28 (static libc++).
set -euxo pipefail
: "${NDK:?}" "${LLVM_TAG:?}"
API=28
NDKBIN="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"

sudo rm -rf /usr/share/dotnet /opt/ghc /usr/local/.ghcup /opt/hostedtoolcache/CodeQL || true
df -h /

git clone --depth 1 --branch "$LLVM_TAG" https://github.com/llvm/llvm-project.git
SRC="$PWD/llvm-project/llvm"

# 1) native tablegen tools
cmake -S "$SRC" -B build-host -G Ninja -DCMAKE_BUILD_TYPE=Release \
  -DLLVM_ENABLE_PROJECTS="clang;lld" -DLLVM_TARGETS_TO_BUILD=AArch64 \
  -DLLVM_INCLUDE_TESTS=OFF -DLLVM_ENABLE_ASSERTIONS=OFF
ninja -C build-host llvm-tblgen clang-tblgen llvm-min-tblgen

# 2) the Android build
cmake -S "$SRC" -B build-android -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-$API -DANDROID_STL=c++_static \
  -DCMAKE_BUILD_TYPE=MinSizeRel \
  -DLLVM_NATIVE_TOOL_DIR="$PWD/build-host/bin" \
  -DLLVM_HOST_TRIPLE=aarch64-linux-android$API \
  -DLLVM_DEFAULT_TARGET_TRIPLE=aarch64-linux-android$API \
  -DLLVM_TARGETS_TO_BUILD=AArch64 \
  -DLLVM_ENABLE_PROJECTS="clang;lld" \
  -DLLVM_INCLUDE_TESTS=OFF -DLLVM_INCLUDE_EXAMPLES=OFF \
  -DLLVM_INCLUDE_BENCHMARKS=OFF -DLLVM_INCLUDE_DOCS=OFF \
  -DCLANG_INCLUDE_TESTS=OFF -DCLANG_INCLUDE_DOCS=OFF \
  -DLLVM_ENABLE_TERMINFO=OFF -DLLVM_ENABLE_ZLIB=OFF -DLLVM_ENABLE_ZSTD=OFF -DLLVM_ENABLE_LIBXML2=OFF \
  -DLLVM_ENABLE_PLUGINS=OFF -DCLANG_PLUGIN_SUPPORT=OFF \
  -DCLANG_ENABLE_ARCMT=OFF -DCLANG_ENABLE_STATIC_ANALYZER=OFF \
  -DCLANG_DEFAULT_LINKER=lld -DCLANG_DEFAULT_CXX_STDLIB=libc++ \
  -DCLANG_DEFAULT_RTLIB=compiler-rt -DCLANG_DEFAULT_UNWINDLIB=libunwind \
  -DLLVM_BUILD_TOOLS=OFF -DLLVM_ENABLE_ASSERTIONS=OFF \
  -DLLVM_PARALLEL_LINK_JOBS=1
ninja -C build-android clang lld llvm-ar

mkdir -p out/llvm
cp -L build-android/bin/clang   out/llvm/libclang.so
cp -L build-android/bin/lld     out/llvm/libld_lld.so
cp -L build-android/bin/llvm-ar out/llvm/libllvm_ar.so
"$NDKBIN/llvm-strip" --strip-all out/llvm/*.so
ls -l out/llvm
