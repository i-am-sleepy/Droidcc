#!/usr/bin/env bash
# Cross-compiles ninja for Android. Patches /bin/sh -> /system/bin/sh (Android has no /bin).
set -euxo pipefail
: "${NDK:?}"
git clone --depth 1 --branch v1.12.1 https://github.com/ninja-build/ninja.git ninja-src
grep -rl '"/bin/sh"' ninja-src/src | xargs sed -i 's|"/bin/sh"|"/system/bin/sh"|g'
grep -rn '/system/bin/sh' ninja-src/src
cmake -S ninja-src -B ninja-build -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-28 -DANDROID_STL=c++_static \
  -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=OFF
ninja -C ninja-build ninja
mkdir -p out/extras
cp ninja-build/ninja out/extras/libninja.so
"$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip" --strip-all out/extras/libninja.so
