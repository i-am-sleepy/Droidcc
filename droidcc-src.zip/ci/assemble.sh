#!/usr/bin/env bash
set -euxo pipefail
mkdir -p app/src/main/jniLibs/arm64-v8a app/src/main/assets
cp out/llvm/*.so out/extras/libninja.so app/src/main/jniLibs/arm64-v8a/
cp out/extras/sysroot.zip app/src/main/assets/sysroot.zip
ls -lR app/src/main/jniLibs app/src/main/assets
